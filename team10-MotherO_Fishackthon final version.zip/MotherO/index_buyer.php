<!-- Shopping cart -->


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en" xml:lang="en" >
<head><title>承銷人個人助理</title>
<meta charset="UTF-8">
	<link href="storefront/view/default/stylesheet/style.css" rel="stylesheet" type='text/css' />
	

<body><center>


<form method="post">	
		<table border=0  width=300px>
			
			<span class="maintext" style="font-size:24pt"><i class="fa fa-shopping-cart fa-fw"></i> <B>承銷人個人助理</b></span></tr>

<!-- shopping cart table -->	
			<tr>				
				<td><button style="height:200px;width:300px" formaction="/mothero/opa/fishmarket.jpg"> 魚市地圖</button></td>
				<td><button type="submit"  style="height:200px;width:300px" formaction="/motherO/opa/shoppingcart.php" > 進行中拍賣</button></td>
				
			</tr>
			<tr>
				<td><button style="height:200px;width:300px" formaction="camera.html"> 參加競價</button></td>
				<td><button style="height:200px;width:300px" formaction="/motherO/opa/buyerhistory.php" > 歷史紀錄</button></td>
			</tr>
		</table>		

</form>
</center>
</body></html>