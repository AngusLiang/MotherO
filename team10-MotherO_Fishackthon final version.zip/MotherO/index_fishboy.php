﻿<!-- Shopping cart -->


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en" xml:lang="en" >
<head><title>討海人個人助理</title>
<meta charset="UTF-8">

	<link href="storefront/view/default/stylesheet/style.css" rel="stylesheet" type='text/css' />
	
	<style>
.visible-print  { display: inherit !important; }
.hidden-print   { display: none !important; }

a[href]:after {
	content: none !important;
}
</style>

<body>

<center>



<div id="maincontainer">
		
	
<form method="post">	
		<table border=0 width=300px>
			<tr>
	<span class="maintext" style="font-size:24pt"><i class="fa fa-shopping-cart fa-fw"></i> <B>討海人個人助理</b></span></tr>
	
<!-- shopping cart table -->	
			<tr>								
				<td><button type="submit"  style="height:130px;width:300px" formaction="/motherO/opa/fishboyshoppingcart.php" > 進行中拍賣</button></td>
				<td><button style="height:130px;width:300px"  formaction="/motherO/opa/history.php" >歷史紀錄</button></td>
			</tr>
			<tr>
				<td><button style="height:130px;width:300px"formaction="/motherO/opa/fuel.htm"> 燃料價格</button></td>
				<td><button style="height:130px;width:300px" formaction="/motherO/opa/weather.htm"> 天氣預報</button></td>
				
			</tr>
			<tr>
				<td><button style="height:130px;width:300px" formaction="/motherO/marineweather.JPG"> 海象圖</button></td>
				<td><button style="height:130px;width:300px" formaction="/motherO/opa/urgent.htm"> 緊急求救</button></td>
			</tr>
			
		</table>		

</form>
</center>
</body></html>