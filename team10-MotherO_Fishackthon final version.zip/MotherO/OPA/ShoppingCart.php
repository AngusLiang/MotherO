<!-- Shopping cart -->

<?php 
/*
$servername = "localhost";
$username = "mothero";
$password = "1234";


// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";
*/
	$db_host = "localhost";
	$db_name = "MotherO";
	$db_user = "mothero";
	$db_password	= "1234";

    $dsn = "mysql:host=$db_host;dbname=$db_name;charset=UTF8";
    $dbh = new PDO($dsn, $db_user, $db_password);

    $sql = "SELECT a.TNo, a.Role, a.RName, a.Price, a.Close,
       Role.Role as CRole, Role.Name as CName,
       Collect.Bucket, Collect.Weight, Collect.Quality, Collect.MaxPrice, Collect.Count,
       a.AreaName, a.PortName, a.OName, a.BName,
       a.MName, a.AName, a.FCategory, a.FName
FROM
(
    SELECT TNo,
           Role.Role as Role, Role.Name as RName,
           Price, Close,
           CollectNo, CollectRoleID, CollectBucket,
           Area.Name as AreaName,
           Port.Name as PortName,
           Owner.OName as OName, Owner.BName as BName,   
           Market.MName as MName, Market.AName as AName,
           Fish.Category as FCategory, Fish.Name as FName
    FROM `Transaction`, `Role`, `Area`, `Port`, `Owner`, `Market`, `Fish`
    WHERE TNo = Role.ID AND
          AreaID = Area.ID AND
          PortID = Port.ID AND
          OwnerOID = Owner.OID AND
          OwherBID = Owner.BID AND
          MarketMID = Market.MID AND
          MarketAID = Market.AID AND
          FishID = Fish.ID
) a, `Collect`, `Role`
WHERE CollectNo = Collect.CNo AND
      CollectRoleID = Collect.RoleID AND
      CollectBucket = Collect.Bucket AND
      CollectRoleID = Role.ID";



?>    


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en" xml:lang="en" >
<head><title>Shopping Cart</title>
<meta charset="UTF-8">
<!--[if IE]>
	<meta http-equiv="x-ua-compatible" content="IE=Edge" />
<![endif]-->
<meta name="generator" content="AbanteCart v1.2.12 - Open Source eCommerce solution" />

<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<base href="http://127.0.0.1/mothero/style" />


	<link href="bootstrap.min.css" rel="stylesheet" type='text/css' />
	<link href="flexslider.css" rel="stylesheet" type='text/css' />
	<link href="onebyone.css" rel="stylesheet" type='text/css' />
	<link href="font-awesome.min.css" rel="stylesheet" type='text/css' />
	<link href="style.css" rel="stylesheet" type='text/css' />

<style>
.visible-print  { display: inherit !important; }
.hidden-print   { display: none !important; }

a[href]:after {
	content: none !important;
}
</style>

	<script type="text/javascript" src="storefront/view/default/javascript/jquery-1.12.4.min.js"></script>
	<script type="text/javascript" src="storefront/view/default/javascript/jquery-migrate-1.2.1.min.js"></script>


<script type="text/javascript">
	var baseUrl = 'http://127.0.0.1/abante/';

	function update_cart(product_id){

		var senddata = {},
			result = false;
		if(product_id){
			senddata['product_id'] = product_id;
		}
		$.ajax({
                url:'http://127.0.0.1/abante/index.php?rt=r/product/product/addToCart',
                type:'GET',
                dataType:'json',
                data: senddata,
				async: false,
                success:function (data) {
					//top cart
					$('.nav.topcart .dropdown-toggle span').first().html(data.item_count);
					$('.nav.topcart .dropdown-toggle .cart_total').html(data.total);
					if($('#top_cart_product_list')){
						$('#top_cart_product_list').html(data.cart_details);
					};
	                result = true;
                }
        });
		return result;
	}

	//event for adding product to cart by ajax
	$(document).on('click', 'a.productcart', function() {
        var item = $(this);
        //check if href provided for product details access
        if ( item.attr('href') && item.attr('href') != '#') {
        	return true;
        }
        if(item.attr('data-id')){
	        if( update_cart(item.attr('data-id')) == true ) {
		        var alert_msg = '<div class="quick_basket">'
				        + '<a href="http://127.0.0.1/abante/index.php?rt=checkout/cart" title="Added to cart">'
				        + '<i class="fa fa-shopping-cart fa-fw"></i></a></div>';
				item.closest('.thumbnail .pricetag').addClass('added_to_cart').prepend(alert_msg);
	        }
        }
    return false;
});
$(window).on('load', function(){
	update_cart();
});
$(document).on('click','a.call_to_order',function(){
	goTo('http://127.0.0.1/abante/index.php?rt=content/contact');
	return false;
});

function search_submit () {
    var url = 'http://127.0.0.1/abante/index.php?rt=product/search';
	var filter_keyword = $('#filter_keyword').val();
	if (filter_keyword) {
	    url += '&keyword=' + encodeURIComponent(filter_keyword);
	}
	var filter_category_id = $('#filter_category_id').attr('value');
	if (filter_category_id) {
	    url += '&category_id=' + filter_category_id;
	}
	location = url;
	return false;
}
</script></head>
<body>
<form><button type="submit"  formaction="/motherO/index_buyer.php" >返回主畫面</button></form>
<center>

<!-- header_bottom blocks placeholder -->
<table>


</table>


	
	<BR>
	
	<font size= 24><B>進行中的拍賣清單<B></font>
	<td> &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </td><td>排序方式</td>
	<td>
		<select>
			<option value="area"> 拍賣區</option>
			<option value="fishtype"> 魚類 </option>
			<option value="fishname"> 魚名 </option>		
		</select>
	</td>
	</h1>
	
<form
        id="cart"
        action="http://127.0.0.1/abante/index.php?rt=checkout/cart"        method="post"        enctype="multipart/form-data"        >
		
<div class="contentpanel">
	<div class="container-fluid cart-info product-list">
		<table border=1>

<!-- shopping cart table -->	

			<tr>
				<th class="align_center">拍賣區</th>
				<th class="align_center">拍賣編號</th>
				<th class="align_center">魚類</th>
				<th class="align_center">魚名</th>
				<th class="align_center">出價次數</th>	
				<th class="align_center">品質</th>
				<th class="align_center">重量</th>
				<th class="align_center">目前出價</th>
				<th class="align_center">一口價</th>							
			</tr>
			
<?php 


$sth = $dbh->query($sql);	
$datalist = $sth->fetchAll();
$i=10;

foreach($datalist as $result)
{
	
?>
			<tr>
					<td class="align_center"><?php echo $result['AName'] ?> </td>
					<td class="align_center"><?php echo $result['TNo'] ?></td>
					<td class="align_center"><?php echo $result['FCategory'] ?></td>
					<td class="align_center"><?php echo $result['FName'] ?></td>
					<td class="align_center"><?php echo $i--; ?></td>					
					<td class="align_center">
					<?php  
						switch($result['Quality']){
							
							case 1:
								echo "極優";
								break;
							case 2:
								echo "優";
								break;
							case 3:
								echo "普通";
								break;
							case 4:
								echo "差";
								break;
							case 5:
								echo "極差";							
								break;
						}
					?>
					
					</td>					
					<td class="align_center"><?php echo $result['Weight'] ?>	</td>					
					<td class="align_center"><?php echo $result['Price'] ?>				
						<button formaction="">+10</button>
						<button formaction="">+5</button>
						<button formaction="">+1</button>
					</td>
					<td class="align_center">						
						<input type="button" value="<?php echo $result['MaxPrice'] ?>"></input>
					</td>
			</tr>

<?php
}
?>
		</table>
		<div class="pull-right mb20">						
						<button formaction="">更新資料</button>
					</div>
	
	</form>



<script type="text/javascript" src="storefront/view/default/javascript/bootstrap.min.js" defer></script>
<script type="text/javascript" src="storefront/view/default/javascript/common.js" defer async></script>
<script type="text/javascript" src="storefront/view/default/javascript/respond.min.js" defer async></script>
<script type="text/javascript" src="storefront/view/default/javascript/jquery.flexslider.min.js" defer async></script>
<script type="text/javascript" src="storefront/view/default/javascript/easyzoom.js" defer async></script>
<script type="text/javascript" src="storefront/view/default/javascript/jquery.validate.min.js" defer async></script>
<script type="text/javascript" src="storefront/view/default/javascript/jquery.carouFredSel.min.js" defer async></script>
<script type="text/javascript" src="storefront/view/default/javascript/jquery.mousewheel.min.js" defer async></script>
<script type="text/javascript" src="storefront/view/default/javascript/jquery.touchSwipe.min.js" defer async></script>
<script type="text/javascript" src="storefront/view/default/javascript/jquery.ba-throttle-debounce.min.js" defer async></script>
<script type="text/javascript" src="storefront/view/default/javascript/jquery.onebyone.min.js" defer async></script>
<script type="text/javascript" src="storefront/view/default/javascript/custom.js" defer async></script>

</center>
</body></html>

<?php
 $dbh = NULL;
 ?>