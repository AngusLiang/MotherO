<html lang="en" lang="en" dir="ltr" xml:lang="en" xmlns="http://www.w3.org/1999/xhtml"><head><title>Shopping Cart</title>
<meta charset="UTF-8">
<!--[if IE]>
	<meta http-equiv="x-ua-compatible" content="IE=Edge" />
<![endif]-->
<meta name="generator" content="AbanteCart v1.2.12 - Open Source eCommerce solution">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<base href="http://127.0.0.1/mothero/style">


	<link href="bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href="flexslider.css" rel="stylesheet" type="text/css">
	<link href="onebyone.css" rel="stylesheet" type="text/css">
	<link href="font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="style.css" rel="stylesheet" type="text/css">

<style>
.visible-print  { display: inherit !important; }
.hidden-print   { display: none !important; }

a[href]:after {
	content: none !important;
}
</style>

	<script src="storefront/view/default/javascript/jquery-1.12.4.min.js" type="text/javascript"></script>
	<script src="storefront/view/default/javascript/jquery-migrate-1.2.1.min.js" type="text/javascript"></script>


<script type="text/javascript">
	var baseUrl = 'http://127.0.0.1/abante/';

	function update_cart(product_id){

		var senddata = {},
			result = false;
		if(product_id){
			senddata['product_id'] = product_id;
		}
		$.ajax({
                url:'http://127.0.0.1/abante/index.php?rt=r/product/product/addToCart',
                type:'GET',
                dataType:'json',
                data: senddata,
				async: false,
                success:function (data) {
					//top cart
					$('.nav.topcart .dropdown-toggle span').first().html(data.item_count);
					$('.nav.topcart .dropdown-toggle .cart_total').html(data.total);
					if($('#top_cart_product_list')){
						$('#top_cart_product_list').html(data.cart_details);
					};
	                result = true;
                }
        });
		return result;
	}

	//event for adding product to cart by ajax
	$(document).on('click', 'a.productcart', function() {
        var item = $(this);
        //check if href provided for product details access
        if ( item.attr('href') && item.attr('href') != '#') {
        	return true;
        }
        if(item.attr('data-id')){
	        if( update_cart(item.attr('data-id')) == true ) {
		        var alert_msg = '<div class="quick_basket">'
				        + '<a href="http://127.0.0.1/abante/index.php?rt=checkout/cart" title="Added to cart">'
				        + '<i class="fa fa-shopping-cart fa-fw"></i></a></div>';
				item.closest('.thumbnail .pricetag').addClass('added_to_cart').prepend(alert_msg);
	        }
        }
    return false;
});
$(window).on('load', function(){
	update_cart();
});
$(document).on('click','a.call_to_order',function(){
	goTo('http://127.0.0.1/abante/index.php?rt=content/contact');
	return false;
});

function search_submit () {
    var url = 'http://127.0.0.1/abante/index.php?rt=product/search';
	var filter_keyword = $('#filter_keyword').val();
	if (filter_keyword) {
	    url += '&keyword=' + encodeURIComponent(filter_keyword);
	}
	var filter_category_id = $('#filter_category_id').attr('value');
	if (filter_category_id) {
	    url += '&category_id=' + filter_category_id;
	}
	location = url;
	return false;
}
</script></head>
<body>
<form><button type="submit"  formaction="/motherO/index_buyer.php" >返回主畫面</button></form>
<center>

<!-- header_bottom blocks placeholder -->
<table>


</table>


	
	<br>
	
	<font size= 24><B>參加競價<B></font>
	 
	
	
<form id="cart" action="http://127.0.0.1/abante/index.php?rt=checkout/cart" enctype="multipart/form-data" method="post">
		
<div class="contentpanel">
	<div class="container-fluid cart-info product-list">
		<table border="1">

<!-- shopping cart table -->	

			<tbody><tr>
				<th class="align_center">拍賣區</th>
				<th class="align_center">拍賣編號</th>
				<th class="align_center">魚類</th>
				<th class="align_center">魚名</th>
				<th class="align_center">出價次數</th>	
				<th class="align_center">品質</th>
				<th class="align_center">重量</th>
				<th class="align_center">目前出價</th>
				<th class="align_center">一口價</th>							
			</tr>
			
			<tr>
					<td class="align_center">鰹鮪魚區 </td>
					<td class="align_center">3</td>
					<td class="align_center">黃魚類</td>
					<td class="align_center">黃花</td>
					<td class="align_center">10</td>					
					<td class="align_center">
					優					
					</td>					
					<td class="align_center">2	</td>					
					<td class="align_center">89				
						<button formaction="/mothero/opa/ShoppingCart.php">+10</button>
						<button formaction="/mothero/opa/ShoppingCart.php">+5</button>
						<button formaction="/mothero/opa/ShoppingCart.php">+1</button>
					</td>
					<td class="align_center">						
						<input type="button" value="500" formaction="shoppCart.php">
					</td>
			</tr>

		</tbody></table>
		<div class="pull-right mb20">						
						<button formaction="">更新資料</button>
					</div>
	
	



<script src="storefront/view/default/javascript/bootstrap.min.js" defer="" type="text/javascript"></script>
<script src="storefront/view/default/javascript/common.js" defer="" type="text/javascript" async=""></script>
<script src="storefront/view/default/javascript/respond.min.js" defer="" type="text/javascript" async=""></script>
<script src="storefront/view/default/javascript/jquery.flexslider.min.js" defer="" type="text/javascript" async=""></script>
<script src="storefront/view/default/javascript/easyzoom.js" defer="" type="text/javascript" async=""></script>
<script src="storefront/view/default/javascript/jquery.validate.min.js" defer="" type="text/javascript" async=""></script>
<script src="storefront/view/default/javascript/jquery.carouFredSel.min.js" defer="" type="text/javascript" async=""></script>
<script src="storefront/view/default/javascript/jquery.mousewheel.min.js" defer="" type="text/javascript" async=""></script>
<script src="storefront/view/default/javascript/jquery.touchSwipe.min.js" defer="" type="text/javascript" async=""></script>
<script src="storefront/view/default/javascript/jquery.ba-throttle-debounce.min.js" defer="" type="text/javascript" async=""></script>
<script src="storefront/view/default/javascript/jquery.onebyone.min.js" defer="" type="text/javascript" async=""></script>
<script src="storefront/view/default/javascript/custom.js" defer="" type="text/javascript" async=""></script>

</div></div></form></center>


</body></html>