// JavaScript Document
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);

NS4=(document.layers)?true:false;
IE4=(document.all)?true:false;
NS6=((document.getElementById)&&(!IE4))?true:false;

var pre_area = "area1";
function showdata(whichL) {
if(IE4) {
ff = eval(whichL);
pp = eval(pre_area);
/*
pp.style.visibility="hidden";
ff.style.visibility="visible";
*/
pp.style.display="none";
ff.style.display="block";
}
else if(NS6) {
ff = document.getElementById(whichL);
pp = document.getElementById(pre_area);
/*
pp.style.visibility="hidden";
ff.style.visibility="visible";
*/
pp.style.display="none";
ff.style.display="block";
}
pre_area = whichL;
}

var pre_sea = "inshore01";
function showsea(whichSea) {
//alert('showsea_'+whichSea);
if(IE4) {
ff = eval(whichSea);
pp = eval(pre_sea);
/*
pp.style.visibility="hidden";
ff.style.visibility="visible";
*/
pp.style.display="none";
ff.style.display="block";
}
else if(NS6) {
ff = document.getElementById(whichSea);
pp = document.getElementById(pre_sea);
/*
pp.style.visibility="hidden";
ff.style.visibility="visible";
*/
pp.style.display="none";
ff.style.display="block";
}
pre_sea = whichSea;
}