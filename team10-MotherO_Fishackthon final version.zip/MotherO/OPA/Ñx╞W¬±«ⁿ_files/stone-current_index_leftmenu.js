//Menu縮放
$(function () {

    //HideLevOne();

    $(".levOne").click(function () {
        var index = $(".levOne").index(this);
        HideLevOne(index);

        var obj = $(this).next();
        if ($(obj).attr("class") != 'levOne') {
            $(obj).toggle();
        }
    });

    $("#Navigator").find("li").click(function () {
        if ($(this).attr("class") != 'levOne') {
            HideLevOne();
            $(this).parent().show();
            $(this).find("a").eq(0).css("color", "#69af0f");
        }
    });

});

function HideLevOne(index) {
    $(".levOne").each(function () {
        var obj = $(this).next();
        if ($(obj).attr("class") != 'levOne') {
            if ($(".levOne").index(this) != index) {
                //$(this).hide();
                $(obj).hide();
                $(obj).find("a").each(function () {
                    $(this).css("color", "#434343");
                });
            }
        }
    });
}
