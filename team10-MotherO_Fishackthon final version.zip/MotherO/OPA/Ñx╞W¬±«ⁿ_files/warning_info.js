var warningInfo=new Array(
new Array("FIFOWS_ZIP","天氣警特報","/V7/prevent/fifows/index.htm?","2018/02/03 14:37"),
new Array("PW26","大雨特報","/V7/prevent/warning/w26.htm?","2018/02/03 14:40"),
new Array("PW25","陸上強風特報","/V7/prevent/warning/w25.htm?","2018/02/03 14:40"),
new Array("PW28","低溫特報","/V7/prevent/warning/w28.htm?","2018/02/03 14:35")
);