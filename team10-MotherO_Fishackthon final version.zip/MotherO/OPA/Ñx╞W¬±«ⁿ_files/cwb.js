function readTXT_W50(url, divname,encoding, iframe) {
	$.ajax({
	  cache : false,
	  beforeSend: function() {   
		$('#'+divname).html("<center><H1>.....資料載入中.......</H1></center>");  
	  },  
      url: url,
      global: false,
	  async: true,
      type: "GET",
	  contentType: "text/plain; charset='"+encoding+"'",
      dataType: "text",
      success: function(msg){
		  if(iframe=='1')
			$('#'+divname).html(msg+"<center><iframe scrolling=no name=\"video\" id=\"video\" title=\"雲寶\" src=\"/V7/forecast/taiwan/W50map.htm\" width=300 height=300 frameborder=0 style=\"overflow:hidden\"></iframe></center>");
		  else
			$('#'+divname).html(msg);
      },
      error: function(xhr,error){
		  if (error == "timeout") {
			  $('#'+divname).html("<center>Timeout</center>");
		  }
		  else {
			$('#'+divname).html("<center>" + xhr.responseText+"</center>");
		  }
      }
	})

}



		 //$('#'+divname).html("<pre>"+msg+"</pre><iframe scrolling=no name=\"video\" id=\"video\" title=\"雲寶\" src=\"\" width=300 height=300 frameborder=0 style=\"overflow:hidden\"></iframe>");

function readTXT(url, divname,encoding) {
	$.ajax({
	  cache : false,
	  beforeSend: function() {   
		$('#'+divname).html("<center><H1>.....資料載入中.......</H1></center>");  
	  },  
      url: url,
      global: false,
	  async: true,
      type: "GET",
	  contentType: "text/plain; charset='"+encoding+"'",
      dataType: "text",
      success: function(msg){
		 $('#'+divname).html(msg);
      },
      error: function(xhr,error){
		  if (error == "timeout") {
			  $('#'+divname).html("<center>Timeout</center>");
		  }
		  else {
			$('#'+divname).html("<center>" + xhr.responseText+"</center>");
		  }
      }
	})
}


function read_modules(url, divname,encoding) {
	$.ajax({
	  cache : false,
	  beforeSend: function() {   
		$('#'+divname).html("<center><H1>.....資料載入中.......</H1></center>");  
	  },  
      url: url,
      global: false,
	  async: true,
      type: "GET",
	  contentType: "text/plain; charset='"+encoding+"'",
      dataType: "text",
      success: function(msg){
		 $('#'+divname).html(msg);
      },
      error: function(xhr,error){
		  if (error == "timeout") {
			  $('#'+divname).html("<center>Timeout</center>");
		  }
		  else {
			$('#'+divname).html("<center>" + xhr.responseText+"</center>");
		  }
      }
	})
}

/*
function readPDF(url, divname,encoding) {
	$.ajax({
	  beforeSend: function() {   
		$('#'+divname).html("<center><H1>.....資料載入中.......</H1></center>");  
	  },  
      url: url,
      global: false,
	  async: true,
      type: "GET",
	  contentType: "text/plain; charset='"+encoding+"'",
      dataType: "text",
      success: function(msg){
		 $('#'+divname).html(msg);
      },
      error: function(xhr,error){
		  $('#'+divname).html("<center>" + xhr.responseText+"</center>");
      }
	})
}
*/

function readMyText(url, divname,encoding) {
	$.ajax({
	  cache : false,
	  beforeSend: function() {   
		$('#'+divname).html("<center><H1>.....資料載入中.......</H1></center>");  
	  },  
      url: url,
      global: false,
	  async: true,
      type: "GET",
	  contentType: "text/plain; charset='"+encoding+"'",
      dataType: "text",
      success: function(msg){
		 $('#'+divname).html(msg);
 	 	 $('.vertical_scroller').SetScroller({	velocity: 	 100,
												direction: 	 'vertical',
												startfrom: 	 'right',
												loop:		 'infinite',
												movetype: 	 'linear',
												onmouseover: 'pause',
												onmouseout:  'play',
												onstartup: 	 'play',
												cursor: 	 'pointer'
		 });

      },
      error: function(xhr,error){
		  if (error == "timeout") {
			  $('#'+divname).html("<center>Timeout</center>");
		  }
		  else {
			$('#'+divname).html("<center>" + xhr.responseText+"</center>");
		  }
      }
	})
}
