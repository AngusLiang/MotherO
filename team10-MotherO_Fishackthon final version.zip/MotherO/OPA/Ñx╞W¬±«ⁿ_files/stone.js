//區域跟Menu縮放
$(function () {
    // chain
    $('.BoxHead').click(function () {
        //$('.qoo').slideUp("fast").removeClass('qoo');
        $(this).next().toggle("fast");
    });

    //var boxs = ['box1', 'box2', 'box3', 'box4', 'box5', 'box6', 'box7', 'box8', 'box9', 'box10'];
    var boxs = ['box1', 'box2', 'box4', 'box5', 'box6', 'box8', 'box9', 'box10'];
    $.each(boxs, function (index, vo) {
        //$('#' + vo).toggle();
        $('#' + vo).show();
    });

    function HidMenu() {
        $("#Navigator li").each(function () {
            $(this).hide();
        });
    }
    $("#Navigator h3").click(function () {
        $(this).parent().find("li").each(function () {
            $(this).toggle();
        });
    });

    //Hidhelptabs();
    //$("#helptabs div").eq(0).show();
    function Hidhelptabs(index) {
        $("#helptabs div.aa").each(function () {
            if ($("#helptabs div.aa").index(this) != index) {
                $(this).hide();
            }
        });
    }
    $("#helptabs li").click(function () {
        var index = $("#helptabs li").index(this);
        Hidhelptabs(index);
        $("#helptabs div.aa").eq(index).toggle(500);
    });

    //SubTab clearfix
    $(".SubTab").find("a").click(function () {
        var index = $(this).parent().parent().find("a").index(this);
        $(this).parent().parent().find("a").each(function () {
            $(this).removeClass("current");
        });
        $(this).addClass("current");

        $(this).parent().parent().parent().find("div").each(function () {
            $(this).hide();
        });
        $(this).parent().parent().parent().find("div").eq(index).show();
    });
});

// Tabs
$(function () {

	var tabs=['pointtabs','Lifttabs','cloudtabs'];
	
	for(var i=0, len=tabs.length; i<len; i++){
		
		var name=tabs[i];
		$('#'+name).tabs({
			beforeLoad:function(event,ui){
				// for some html, i.e., the index.htm in observe, 
				// there are some divs whose id="${name}_status" to display the status.
				// however, they are needless.
				// you can use just ui.panel.html('...') which is enough.
				// If you want to display message in the divs, use var thisname=name to keep the name.
				// example:
				// var thisname=name;
				// $('#'+thisname+'_status').html('....');
				ui.panel.html("<center><H1>.....資料載入中.....</H1></center>");
				ui.ajaxSettings.cache=false;
				ui.ajaxSettings.timeout=10000;
				ui.ajaxSettings.error=function(xhr,status,err){
					if(status=='timeout'){
						ui.panel.html("The request timed out, please resubmit");
					}else{
						// don't use xhr.responseText which shows the apache version (dangerous)
						ui.panel.html("<center>" + err +"</center>");
					}
				};
				// need not to define the callback for success. the content will be cleared.
				// you can try it.

			}
		
		});
	}
	
	$("#Realtabs").tabs({
		beforeLoad:function(event,ui){
			ui.panel.html("<center><H1>.....資料載入中.....</H1></center>");
			ui.ajaxSettings.cache=false;
			ui.ajaxSettings.timeout=10000;
			ui.ajaxSettings.error=function(xhr,status,err){
				if(status=='timeout'){
					ui.panel.html("The request timed out, please resubmit");
				}else{
					// don't use xhr.responseText which shows the apache version (dangerous)
					ui.panel.html("<center><H1>OOPS!!該站沒有提供此資料</H1></center>");   
				}
			};
				// need not to define the callback for success. the content will be cleared.
				// you can try it. 

		},
	});
	
	var tabs=['locationtabs','temptabs','newstabs','ty_map_1','ty_map_2','ty_map_3'];
	for(var i=0, len=tabs.length; i<len; i++){
		var name=tabs[i];
		$('#'+name).tabs();
	}

});

//天氣換圖與播放
var now_td = -1;
var is_play = 0;
$(function () {
    $("#tabMapDate tr").eq(0).find("td").click(function () {
        //$("#tabMapDate td").removeClass("thisday");
        //$(this).addClass("thisday");

        var my_i = $("#tabMapDate tr").eq(0).find("td").index(this);

        var count = 0;
        for (var i = 0; i < my_i; i++) {
            var myTd = $("#tabMapDate tr").eq(0).find("td").eq(i);
            count += $(myTd).prop("colspan");
        }

        now_td = count;

        //$("#tabMapDate tr").eq(1).find("td").eq(count).addClass("thisday");
        //$("#divTWmap").prop({ style: "background-image:url(" + $("#tabMapDate tr").find(":hidden").eq(count).val() + ")" });

        SetTimeWeather(now_td);
    });

    SetTimeWeather(0);

    $("#tabMapDate tr").eq(1).find("td").click(function () {
        now_td = $("#tabMapDate tr").eq(1).find("td").index(this);
        SetTimeWeather(now_td);
    });

});

function SetTimeWeather(my_i) {
    $("#tabMapDate td").removeClass("thisday");
    $("#tabMapDate tr").eq(1).find("td").eq(my_i).addClass("thisday");

    $("#divTWmap").attr({ style: "background-image:url(" + $("#tabMapDate tr").find(":hidden").eq(my_i).val() + ")" });

    var count = 0;
    var i = 0;

    while (my_i >= count) {
        var myTd = $("#tabMapDate tr").eq(0).find("td").eq(i);
        count += $(myTd).prop("colspan");
        i++;
    }
    i--;

    $("#tabMapDate tr").eq(0).find("td").eq(i).addClass("thisday");

    $("#divTitle a").each(function (e) {
        $(this).prop("title", $("#divTitle div").eq(my_i).find(":hidden").eq(e).val());

    });
}

function StepBck() {
    if (now_td > 0) {
        now_td--;
        SetTimeWeather(now_td);
    }
}
function Stop() {
    is_play = 0;
}
function Start() {
    is_play = 1;
    playDayWeath();
}
function StepFwd() {
    if (now_td < $("#tabMapDate tr").eq(1).find("td").length - 1) {
        now_td++;
        SetTimeWeather(now_td);
    }
}

function playDayWeath() {
    if (is_play == 0) {
        return;
    }

    if (now_td < $("#tabMapDate tr").eq(1).find("td").length - 1) {
        now_td++;
    }
    else {
        now_td = 0;
    }

    SetTimeWeather(now_td);

    setTimeout("playDayWeath( )", 1000)
}

//顯示與隱藏上面部分
$(function () {
    $("#Toproll").click(function () {
        $("#Header").toggle(500);
        //$("#Header .Alarm").toggle(500);
        //$("#Header .CwbLogo").toggle(500);
        //$("#HeaderNavi").toggle(500);
        //$("#Header .clear").toggle(500);

        if ($("#Toproll").val() == "︽") {
			//換成images/icon/up.gif
            $("#Toproll").val("︾");
			//換成images/icon/down.gif
            document.getElementById("GlobalNavi").style.top = "0px";
            //document.getElementById("Header").style.height = "20px";
            //document.getElementById("divToproll").style.top = "20px";
        }
        else {
            $("#Toproll").val("︽");
			
            document.getElementById("GlobalNavi").style.top = "88px";
            //document.getElementById("Header").style.top = "118px";
            //document.getElementById("divToproll").style.top = "108px";
        }
    });
});
