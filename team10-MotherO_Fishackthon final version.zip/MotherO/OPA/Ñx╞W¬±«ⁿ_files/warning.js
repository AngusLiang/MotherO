/*  中文版特報 */
var warning_title=new Array (
new Array("ECHTM","地震特報","/pda/seismic/quake.htm","E"),
new Array("ECTSU","海嘯警報","/V7/earthquake/tsu.htm","E"),
new Array("PTA_NEW","颱風消息","/pda/warning/W21.htm","W"),
new Array("FIFOWS_ZIP","天氣特報","/pda/warning/W21.htm","W"),
new Array("PW21","颱風警報","/pda/warning/W21.htm","W"),
new Array("PW21Lift","解除颱風警報","/pda/warning/W21.htm","W"),
new Array("PW23","熱帶性低氣壓特報", "/pda/warning/W23.htm","W"),
new Array("PW23Lift","解除熱帶性低氣壓特報", "/pda/warning/W23.htm","W"),
new Array("PW24","颱風消息特報", "/pda/warning/W24.htm","W"),
new Array("PW24Lift","解除颱風消息特報", "/pda/warning/W24.htm","W"),
//new Array("PW25","陸上強風特報", "/pda/warning/W25.htm","W"),
//new Array("PW25Lift","陸上強風特報", "/pda/warning/W25.htm","W"),
//new Array("PW26","大雨特報", "/pda/warning/W26.htm","W"),
//new Array("PW26Lift","解除大雨特報", "/pda/warning/W26.htm","W"),
//new Array("PW26Ext","大豪雨特報", "/pda/warning/W26.htm","W"),
//new Array("PW26ExtLift","解除大豪雨特報", "/pda/warning/W26.htm","W"),
//new Array("PW27","濃霧特報", "/pda/warning/W27.htm","W"),
//new Array("PW27Lift","解除濃霧特報", "/pda/warning/W27.htm","W"),
//new Array("PW28","低溫特報", "/pda/warning/W28.htm","W"),
//new Array("PW28Lift","解除低溫特報", "/pda/warning/W28.htm","W"),
new Array("PW30","海上強風特報", "/pda/warning/W30.htm","W"),
new Array("PW30Lift","海上強風特報", "/pda/warning/W30.htm","W"),
new Array("PW33","大雷雨即時訊息", "/pda/warning/W33.htm","W"),
new Array("PW33Lift","解除雷雨特報", "/pda/warning/W33.htm","W"),
new Array("PW34","即時天氣訊息", "/pda/warning/W34.htm","W"),
new Array("PW37","長浪即時訊息","/pda/warning/W37.htm","W"),
new Array("PWS","災防告警訊息","/V7/warning/PWS_History.htm","W"),
new Array("TY_WIND","颱風強風告警","/V7/warning/TyphoonWind.htm","W"),
new Array("999","天文特報", "/V7/warning/999.htm","A")
);

var warning_images=new Array (
new Array("W21","颱風警報","/V7/images/template2013/Typhoon.png"),
new Array("W25","陸上強風特報", "/V7/images/template2013/Gale.png"),
new Array("W26","大雨特報", "/V7/images/template2013/Heavy-rain.png"),
new Array("W27","濃霧特報", "/V7/images/template2013/Fog.png"),
new Array("W28","低溫特報", "/V7/images/template2013/Hypothermia.png"),
new Array("W30","海上強風特報", "/V7/images/template2013/Gale.png")
//new Array("W33","大雷雨即時訊息", "/V7/images/template2013/Heavy-rain.png")
);


var str="";
var find="0";
var result="";
var ahead="";
var buttom="";

function show_warning()
{
		findnum=0;
		num=warningInfo.length;
		for(i=0;i< num; i++)  {
			find="0";
			for(j=0;j<warning_title.length;j++) {
					if(warningInfo[i][0]==warning_title[j][0]) {
						find="1";
						findnum=findnum+1;
						break;
					}
				}
			if (find=="1")
			{
				if ((warningInfo[i][0].search("Lift"))<0) {
					if(warningInfo[i][0]=="ECHTM")
						result=result+"<li><span class=\"text\"><a href="+warningInfo[i][2]+">地震報告</a></span></li>";
					else if(warningInfo[i][0]=="TEDplus")
						result=result+"<li><span class=\"text\"><a href="+warningInfo[i][2]+">颱風警報(新版)</a></span></li>";
					else if(warningInfo[i][0]=="PW21") {
						var rr=warningInfo[i][1].split("("); 
						if(rr[0]=="國際尚未命名颱風"){
							rr[0]="颱風警報";
						}
						result=result+"<li><span class=\"text\"><a href="+warningInfo[i][2]+">"+rr[0]+"</a></span></li>";
					}
					else if(warningInfo[i][0]=="PW33") {
						result=result+"<li><span class=\"text\"><a href="+warningInfo[i][2]+" style=\"font-size:0.85em;\">"+warningInfo[i][1]+"</a></span></li>";
					}
					else
						result=result+"<li><span class=\"text\"><a href="+warningInfo[i][2]+">"+warningInfo[i][1]+"</a></span></li>";
				}
				else {
					if(warningInfo[i][0]=="PW33") {
						result=result+"<li><span class=\"text\"><a href="+warningInfo[i][2]+" style=\"font-size:0.85em;\">"+warningInfo[i][1]+"</a></span></li>";
					}else{
						result=result+"<li><span class=\"text\"><a href="+warningInfo[i][2]+">"+warningInfo[i][1]+"</a></span></li>";
					}
				}
			}
		}
		if(result != "")
			result="<div class=\"Alarm\"><ul>"+result+"</ul></div>";
		document.write(result);

}

function show_wpps()
{ 
	result="";
	num=PWPPSzip.length;
	//num=1;
	if(num >= 1) {
		 result="<a href=\"/V7/forecast/fcst/QPF6.htm?\" target=_blank>定量降水</a><span>│</span>";
		 result=result+"<a href=\"/V7/prevent/warning/WPPS.htm?\">風雨預報</a><span>│</span>";
	}
    document.write(result);
}

function show_windreal()
{ 
	result="";
	num=PWPPS_WINDREAL.length;
	//num=1;
	if(num >= 1) 
		 result="<a href=\"/V7/prevent/warning/WPPS_REG_WindReal.htm?\">實際風力</a><span>│</span>";
    document.write(result);
}
  

function show_warning_in_plan()
{
		findnum=0;
		num=warningInfo.length;
		result="";
		for(i=0;i< num; i++)  {
			find="0";
			for(j=0;j<warning_title.length;j++) {
					if(warningInfo[i][0]==warning_title[j][0] && warning_title[j][3]=='W') {
						find="1";
						findnum=findnum+1;
						break;
					}
				}
			if (find=="1")
			{
				if ((warningInfo[i][0].search("Lift"))<0) {
					result=result+"<li><span class=\"Col01\">"+warningInfo[i][3].substring(5,10)+"</span>";
					result=result+"<span class=\"Col02\">"+warningInfo[i][3].substring(11)+"</span>";
					result=result+"<span class=\"Col04\"><a href='"+warningInfo[i][2]+"'>發布「<font color=red>"+warningInfo[i][1]+"</font>」 !!</a></span>";
					result=result+"<div class=\"clear\"></div></li>";
				}
				else {
					result=result+"<li><span class=\"Col01\">"+warningInfo[i][3].substring(5,10)+"</span>";
					result=result+"<span class=\"Col02\">"+warningInfo[i][3].substring(11)+"</span>";
					result=result+"<span class=\"Col04\"><a href='"+warningInfo[i][2]+"'>發布「<font color=red>"+warningInfo[i][1]+"</font>」</a></span>";
					result=result+"<div class=\"clear\"></div></li>";
				}
			}
		}
		if(findnum == 0) {
			result=result+"<li><span class=\"Col04\">目前並無任何天氣警特報發布!!</span>";
			result=result+"<div class=\"clear\"></div></li>";
		}
		document.write(result);

}

function show_TSU_warning()
{
		findnum=0;
		num=warningInfo.length;
		result="";
		find="0";
		for(i=0;i< num; i++)  {
			if(warningInfo[i][0]==warning_title[1][0]) {
				find="1";
				break;
			}
		}
		if(find == "1") {
//			result=result+"<div id=ECTSU>"+warning_title[1][2]+"</div>";
//			read_modules(warning_title[1][2],'ECTSU','utf-8');
			result=result+"<a href="+warning_title[1][2]+" target=_blank><img width=100% border=0  src=/V7/earthquake/Data/TSU/TSU.gif></a>";
		}
		else {
			result=result+"<p>目前無海嘯資訊 !!</p>";
		}
		document.write(result);

}

function Decide_DIV_Bg(TY, WID, ID)
{
		findnum=0;
		num=warningInfo.length;
		result="";
		if(WID=="") {
			for(i=0;i< num; i++)  {
				find="0";
				for(j=0;j<warning_title.length;j++) {
						if(warningInfo[i][0]==warning_title[j][0] && warning_title[j][3]==TY) {
							find="1";
							findnum=findnum+1;
							break;
						}
				}
			}
		}
		else {
			for(i=0;i< num; i++)  {
				find="0";
				for(j=0;j<warning_title.length;j++) {
						if(warningInfo[i][0]==warning_title[j][0] && warning_title[j][3]==TY && warningInfo[i][0]==WID) {
							find="1";
							findnum=findnum+1;
							break;
						}
				}
			}
		}

		if(findnum == 0) 
			result="BoxEntry";
		else
			result="BoxEntry OrangeBg";

		$(ID).addClass(result);
//		document.write(result);

}

function Decide_Color_TYNEW(div)
{
		num=warningInfo.length;
		result="";
		find=0;
		for(i=0;i< num; i++)  {
			if(warningInfo[i][0]=="PTA_NEW") {
				find=1;
				break;
			}
		}

		if(find == 1) 
			$('#'+div).attr("style","color:red;font-weight:bold;");
//			$('#'+div).attr("color","red");

}

function show_NEWS()
{ 
	result="";
	num=Radar_News.length;
//	num=1;
	if(num >= 1) {
		for(i=0;i<num;i++)  {
			result=result+"<font color=red><li>"+Radar_News[i]+"</li></font>";
		}
//		result=result+"<P>如需北台灣氣象雷達資料, 請參考<a href=ncu.htm target=_blank>中央大學雷達觀測資料</a>";
	}
    document.write(result);
}

function show_SATNEWS()
{ 
	result="";
	num=Sat_News.length;
//	num=1;
	if(num >= 1) {
		for(i=0;i<num;i++)  {
			result=result+"<font color=red><li>"+Sat_News[i]+"</li></font>";
		}
//		result=result+"<P>如需北台灣氣象雷達資料, 請參考<a href=ncu.htm target=_blank>中央大學雷達觀測資料</a>";
	}
    document.write(result);
}

function show_fifos(tid)
{
		//alert(tid);
		$.getScript( '/V7/forecast/town368/warn/'+tid+'.js',
			function(){

		findnum=0;
		num=warningArea.length;
		//alert(num);
		if (num>=1)
		{
			result="<ul class=\"Special-Report\">";
			for(i=0;i< num; i++)  {
					//alert(warningArea[i][0]);
					//alert(warning_title[j][2]);
					//result=result+"<li><a class=\"noeffect\" href="+warning_title[j][2]+"><span class=\"name\"><span class=\"datetime\">"+warningInfo[i][3]+"</span><br />"+warningInfo[i][1]+"</span><span class=\"arrow\"></span></a></li>";
					for(j=0;j<warning_images.length;j++) {
						if(warningArea[i][1]==warning_images[j][0])	{
							img=warning_images[j][2];
							break;
						}

					}

					//result=result+"<li><a href='/V7/prevent/fifows/index.htm?'><img src=\""+img+"\" />"+warningArea[i][0]+"</a></li>";
					//result=result+"<li id=\"Cloudburst_a\"><a href=\'/V7/prevent/fifows/index.htm\'><img src=\""+img+"\"  border=\"0\" align=\"middle\" />"+warningArea[i][0]+"</a></li>";

					result=result+"<li id=\"Cloudburst_a\"><a href=\'/V7/prevent/fifows/index.htm\'><img src=\""+img+"\"  border=\"0\" align=\"middle\" />"+warningArea[i][0]+"</a><div class=\"Special_ReportBox\" id=\"Cloudburst\"><h3>"+warningArea[i][2]+"(發布:"+warningArea[i][3]+")"+"</h3><p><span>"+warningArea[i][0]+"</span><br />"+warningArea[i][4]+"</p></div></li>";

					
			}
			if(result != "")
				result=result+"<div class=\"clear\"></div></ul>";
		}
		else
			result="";

/*
        result="
<ul class=\"Special-Report\">
<li id=\"Cloudburst_a\"><a href=\"http://www.cwb.gov.tw/V7/prevent/fifows/index.htm\" ><img src=\"../images/template2013/Cloudburst.png\" border=\"0\" align=\"middle\" />大雨特報</a><div class=\"Special_ReportBox\" id=\"Cloudburst\">
<h3>連江縣</h3>
<p><span>低溫特報</span><br />
強烈大陸冷氣團影響，今（１４日）晚至明（１５日）晨嘉義以北沿海空曠地區及金門、馬祖將出現攝氏１０度左右之低溫。農漁養殖業及山坡地作物請嚴防寒害；民眾亦請注意保暖；使用瓦斯熱水器具應注意室內通風，以免一氧化碳中毒。</p>
<hr />
<p><span>低溫特報</span><br />
強烈大陸冷氣團影響，今（１４日）晚至明（１５日）晨嘉義以北沿海空曠地區及金門、馬祖將出現攝氏１０度左右之低溫。農漁養殖業及山坡地作物請嚴防寒害；民眾亦請注意保暖；使用瓦斯熱水器具應注意室內通風，以免一氧化碳中毒。</p>
</div></li>
<div class=\"clear\"></div>

</ul>

";
	    result="<ul class=\"Special-Report\"><li id=\"Cloudburst_a\"><a href=\"http://www.cwb.gov.tw/V7/prevent/fifows/index.htm\" ><img src=\"/V7/images/template2013/Cloudburst.png\" border=\"0\" align=\"middle\" />大雨特報</a><div class=\"Special_ReportBox\" id=\"Cloudburst\"><h3>連江縣</h3><p><span>低溫特報</span><br />強烈大陸冷氣團影響，今（１４日）晚至明（１５日）晨嘉義以北沿海空曠地區及金門、馬祖將出現攝氏１０度左右之低溫。農漁養殖業及山坡地作物請嚴防寒害；民眾亦請注意保暖；使用瓦斯熱水器具應注意室內通風，以免一氧化碳中毒。</p></div></li><div class=\"clear\"></div></ul>";
*/

		//alert(result);
		//document.write(result);
		if($('#fifowarn').length) {
			//alert(result);
			$('#fifowarn').html(result);
		}
		else
			alert('null');
	})

}
